/* =========================================================
   COS 106 Term Project — script.js
   Handles: mobile nav toggle, Academic Planner (arrays, DOM
   manipulation, event handling), Contact form validation.
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  initNavToggle();
  initPlanner();
  initContactForm();
  setActiveNavLink();
});

/* ---------------- Navigation ---------------- */
function initNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (!toggle || !links) return;

  toggle.addEventListener("click", function () {
    links.classList.toggle("open");
  });
}

function setActiveNavLink() {
  const links = document.querySelectorAll(".nav-links a");
  const current = window.location.pathname.split("/").pop() || "index.html";
  links.forEach(function (link) {
    const href = link.getAttribute("href");
    if (href === current) link.classList.add("active");
  });
}

/* ---------------- Academic Planner ---------------- */
/* Tasks are stored as an array of objects and persisted in
   localStorage so the planner remembers tasks between visits. */

const PLANNER_KEY = "cos106_planner_tasks";

function loadTasks() {
  const raw = localStorage.getItem(PLANNER_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

function saveTasks(tasks) {
  localStorage.setItem(PLANNER_KEY, JSON.stringify(tasks));
}

function initPlanner() {
  const form = document.getElementById("task-form");
  const list = document.getElementById("task-list");
  if (!form || !list) return; // not on the planner page

  const input = document.getElementById("task-input");
  const prioritySelect = document.getElementById("task-priority");
  const dueInput = document.getElementById("task-due");

  let tasks = loadTasks();
  renderTasks(tasks, list);

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    const text = input.value.trim();
    if (text === "") {
      input.focus();
      return;
    }

    const newTask = {
      id: Date.now(),
      text: text,
      priority: prioritySelect.value,
      due: dueInput.value,
      completed: false,
    };

    tasks.push(newTask); // array usage
    saveTasks(tasks);
    renderTasks(tasks, list);

    form.reset();
    input.focus();
  });

  // Event delegation for complete/delete buttons
  list.addEventListener("click", function (event) {
    const row = event.target.closest(".task-row");
    if (!row) return;
    const id = Number(row.dataset.id);

    if (event.target.classList.contains("task-check")) {
      tasks = tasks.map(function (task) {
        if (task.id === id) task.completed = !task.completed;
        return task;
      });
      saveTasks(tasks);
      renderTasks(tasks, list);
    }

    if (event.target.classList.contains("task-delete")) {
      tasks = tasks.filter(function (task) {
        return task.id !== id;
      });
      saveTasks(tasks);
      renderTasks(tasks, list);
    }
  });
}

function renderTasks(tasks, list) {
  list.innerHTML = "";

  if (tasks.length === 0) {
    const empty = document.createElement("li");
    empty.className = "task-empty";
    empty.textContent = "No tasks yet — add your first academic task above.";
    list.appendChild(empty);
    return;
  }

  // Sort: incomplete first, then by priority
  const priorityRank = { high: 0, medium: 1, low: 2 };
  const sorted = [...tasks].sort(function (a, b) {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    return priorityRank[a.priority] - priorityRank[b.priority];
  });

  sorted.forEach(function (task) {
    const row = document.createElement("li");
    row.className = "task-row" + (task.completed ? " completed" : "");
    row.dataset.id = task.id;
    row.dataset.priority = task.priority;

    const dueLabel = task.due ? "Due " + formatDate(task.due) : "No due date";

    row.innerHTML =
      '<button type="button" class="task-check' +
      (task.completed ? " done" : "") +
      '" aria-label="Toggle complete">' +
      (task.completed ? "&#10003;" : "") +
      "</button>" +
      '<div class="task-text">' +
      escapeHtml(task.text) +
      '<div class="task-meta">' +
      task.priority.toUpperCase() +
      " PRIORITY &middot; " +
      dueLabel +
      "</div></div>" +
      '<button type="button" class="task-delete">Delete</button>';

    list.appendChild(row);
  });
}

function formatDate(value) {
  const d = new Date(value + "T00:00:00");
  if (isNaN(d.getTime())) return value;
  return d.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

/* ---------------- Contact form validation ---------------- */
function initContactForm() {
  const form = document.getElementById("contact-form");
  if (!form) return; // not on the contact page

  const fields = {
    name: document.getElementById("name"),
    email: document.getElementById("email"),
    phone: document.getElementById("phone"),
    message: document.getElementById("message"),
  };
  const status = document.getElementById("form-status");

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    let isValid = true;

    isValid = validateRequired(fields.name, "name-error", "Please enter your name.") && isValid;
    isValid = validateEmail(fields.email, "email-error") && isValid;
    isValid = validatePhone(fields.phone, "phone-error") && isValid;
    isValid = validateRequired(fields.message, "message-error", "Please enter a message.") && isValid;

    if (isValid) {
      status.textContent =
        "Thanks, " + fields.name.value.trim() + "! Your message has been received.";
      status.className = "form-status show ok";
      form.reset();
    } else {
      status.textContent = "Please fix the errors above and try again.";
      status.className = "form-status show bad";
    }
  });

  // Live validation as the user types
  fields.name.addEventListener("input", () => validateRequired(fields.name, "name-error", "Please enter your name."));
  fields.email.addEventListener("input", () => validateEmail(fields.email, "email-error"));
  fields.phone.addEventListener("input", () => validatePhone(fields.phone, "phone-error"));
  fields.message.addEventListener("input", () => validateRequired(fields.message, "message-error", "Please enter a message."));
}

function setError(id, message) {
  const el = document.getElementById(id);
  if (el) el.textContent = message || "";
}

function validateRequired(field, errorId, message) {
  if (field.value.trim() === "") {
    setError(errorId, message);
    return false;
  }
  setError(errorId, "");
  return true;
}

function validateEmail(field, errorId) {
  const value = field.value.trim();
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (value === "") {
    setError(errorId, "Please enter your email address.");
    return false;
  }
  if (!pattern.test(value)) {
    setError(errorId, "Please enter a valid email address (e.g. name@example.com).");
    return false;
  }
  setError(errorId, "");
  return true;
}

function validatePhone(field, errorId) {
  const value = field.value.trim();
  const digitsOnly = /^[0-9]+$/;
  if (value === "") {
    setError(errorId, "Please enter your phone number.");
    return false;
  }
  if (!digitsOnly.test(value)) {
    setError(errorId, "Phone number must contain digits only (no spaces or symbols).");
    return false;
  }
  setError(errorId, "");
  return true;
}
